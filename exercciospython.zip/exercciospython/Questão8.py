valor = float(input("Digite o valor: "));
print("O valor de cada prestação é: ", valor/5);