num = float(input("Digite o número: "));
print("O triplo é: ", num*3);