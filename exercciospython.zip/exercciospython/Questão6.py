nome = input("Digite o nome: ");
endereco = input("Digite o endereço: ");
telefone = input("Digite o telefone: ");
print(nome+" - "+endereco+" - "+telefone);