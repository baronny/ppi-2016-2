num = int(input("Digite o número: "));
print("O antecessor é: ", num-1);
print("O sucessor é: ", num+1);