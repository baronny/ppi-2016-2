preço = float(input("Digite o preço: "));
percentual = float(input("Digite o percentual de acréssimo: "));
print("O valor da venda é: ", preço+(preço*(percentual/100)));