valor = float(input("Digite o valor em reais: "));
print("O resultado é: ",valor*0.7);