num1 = float(input("Digite o primeiro número: "));
num2 = float(input("Digite o segundo número: "));
print("O produto é: ",num1*num2);